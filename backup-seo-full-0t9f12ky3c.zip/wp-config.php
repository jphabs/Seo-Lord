<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'nbaseo' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'GrtGdJsCPs9c53' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         ' bj.l-- =4vl+UL.TR/j%z*,aWb :(<.(z.|rh];|sYF-HubF~CVV!1sj7GRlqp?');
define('SECURE_AUTH_KEY',  '>+Pu{$H|:hoMS+76-n;*lm8]1a{!PVp-)LR)>~S}T0YO=;u2QQ<$+?5Z=S-mk?vq');
define('LOGGED_IN_KEY',    'W#v* C+4q1=u+dt`h=lCB }^K~5TMW=|(x;2mR2}eFH8cMH.m_irub5TXO+qyxQT');
define('NONCE_KEY',        '2jxl(,B#&m]eBnRuNm`=41#E/TPT!`iuNF|0gp- GHdYUFB|.gL]aDjs!Mc3=1+W');
define('AUTH_SALT',        ')nm|/J-uD3Vp*U1{)CCsr`K5mYyb}CO5BUf00]cL.2[]mbUXBnzn^5;?jZ|-~`uU');
define('SECURE_AUTH_SALT', '9:gwn^#3s4j0D)~4,_C B}J?6{VMBctlrWZz(P>#G-xt+`Ivz<-E=!{MgX(U[9|8');
define('LOGGED_IN_SALT',   'iwVW|q0R}hgN}0h/^4MpSZ~p])|tD]|uh Fo/IxNJ%9K$4(`KizFP-;lrYOM-JZ#');
define('NONCE_SALT',       'Mou&N35e8yorH_|nFQ:p6)5wqkO=%qT8t:k)`(<>Ib^j-d2ey|k(}YQY *LuA9pn');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * WordPress Localized Language, defaults to English.
 *
 * Change this to localize WordPress. A corresponding MO file for the chosen
 * language must be installed to wp-content/languages. For example, install
 * de_DE.mo to wp-content/languages and set WPLANG to 'de_DE' to enable German
 * language support.
 */
define('WPLANG', '');

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
